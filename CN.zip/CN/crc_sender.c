#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define GEN "10011"
#define GEN_LEN 5

void xor(char *a,char *b,int len) {
    for(int i=0;i<len;i++)
        a[i]=(a[i]==b[i])?'0':'1';
}

void compute_crc(char *data,char *crc) {
    char temp[200];
    strcpy(temp,data);
    for(int i=0;i<GEN_LEN-1;i++) strcat(temp,"0");
    int tlen=strlen(temp);
    printf("Data with appended zeros: %s\n",temp);

    char div[GEN_LEN+1];
    strncpy(div,temp,GEN_LEN);
    div[GEN_LEN]='\0';

    for(int i=GEN_LEN;i<=tlen;i++) {
        if(div[0]=='1') xor(div,(char *)GEN,GEN_LEN);
        else xor(div,"00000",GEN_LEN);
        if(i<tlen) {
            memmove(div,div+1,GEN_LEN-1);
            div[GEN_LEN-1]=temp[i];
            div[GEN_LEN]='\0';
        }
    }
    strncpy(crc,div+1,GEN_LEN-1);
    crc[GEN_LEN-1]='\0';
}

void to_binary(int n,char *out,int bits) {
    for(int i=bits-1;i>=0;i--) {
        out[i]=(n&1)+'0';
        n>>=1;
    }
    out[bits]='\0';
}

int main() {
    int server_fd,client_fd;
    struct sockaddr_in addr;
    int num;
    char binary[100],crc[GEN_LEN],frame[200];

    printf("Enter a number to send: ");
    scanf("%d",&num);
    to_binary(num,binary,8);
    printf("Binary: %s\n",binary);

    compute_crc(binary,crc);
    printf("CRC: %s\n",crc);

    strcpy(frame,binary);
    strcat(frame,crc);
    printf("Frame (data+CRC): %s\n",frame);

    server_fd=socket(AF_INET,SOCK_STREAM,0);
    int opt=1;
    setsockopt(server_fd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
    addr.sin_family=AF_INET;
    addr.sin_addr.s_addr=INADDR_ANY;
    addr.sin_port=htons(9091);
    bind(server_fd,(struct sockaddr *)&addr,sizeof(addr));
    listen(server_fd,1);
    printf("Waiting for receiver...\n");
    client_fd=accept(server_fd,NULL,NULL);
    send(client_fd,frame,strlen(frame)+1,0);
    printf("Frame sent.\n");
    close(client_fd);
    close(server_fd);
    return 0;
}
