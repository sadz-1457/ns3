#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

void parse_url(char *url,char *host,int *port,char *path) {
    *port=8000;
    sscanf(url,"http://%[^:/]:%d/%s",host,port,path);
    if(path[0]=='\0') strcpy(path,"/");
}

long get_time_ms() {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC,&ts);
    return ts.tv_sec*1000+ts.tv_nsec/1000000;
}

int main() {
    char url[256],host[128],path[128],filename[256];
    int port,sockfd;
    struct sockaddr_in server_addr;
    char request[512],buffer[4096];
    int bytes;
    long total_bytes=0;

    printf("Enter URL: ");
    scanf("%s",url);

    parse_url(url,host,&port,path);
    printf("Host: %s | Port: %d | Path: /%s\n",host,port,path);

    sockfd=socket(AF_INET,SOCK_STREAM,0);
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(port);
    inet_pton(AF_INET,"127.0.0.1",&server_addr.sin_addr);

    long connect_start=get_time_ms();
    connect(sockfd,(struct sockaddr *)&server_addr,sizeof(server_addr));
    long connect_end=get_time_ms();

    sprintf(request,"GET /%s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n",path,host);
    write(sockfd,request,strlen(request));

    sprintf(filename,"downloaded_%s",path);
    FILE *fp=fopen(filename,"wb");

    int header_done=0;
    char header_buf[8192];
    int header_len=0;

    long download_start=get_time_ms();

    while((bytes=read(sockfd,buffer,sizeof(buffer)))>0) {
        if(!header_done) {
            memcpy(header_buf+header_len,buffer,bytes);
            header_len+=bytes;
            char *body=strstr(header_buf,"\r\n\r\n");
            if(body) {
                header_done=1;
                body+=4;
                int body_len=header_len-(body-header_buf);
                fwrite(body,1,body_len,fp);
                total_bytes+=body_len;
            }
        } else {
            fwrite(buffer,1,bytes,fp);
            total_bytes+=bytes;
        }
    }

    long download_end=get_time_ms();
    fclose(fp);
    close(sockfd);

    long response_time=connect_end-connect_start;
    long download_time=download_end-download_start;
    double throughput=(download_time>0)?(double)total_bytes/download_time*1000:0;

    printf("\n--- Performance Report ---\n");
    printf("File saved as   : %s\n",filename);
    printf("Response Time   : %ld ms\n",response_time);
    printf("Download Time   : %ld ms\n",download_time);
    printf("Data Size       : %ld bytes\n",total_bytes);
    printf("Throughput      : %.2f bytes/sec\n",throughput);

    return 0;
}