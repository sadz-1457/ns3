#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char roll[20],buffer[200];
    sockfd=socket(AF_INET,SOCK_DGRAM,0);
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(8080);
    inet_pton(AF_INET,"127.0.0.1",&server_addr.sin_addr);
    printf("Enter Roll Number: ");
    scanf("%s",roll);
    sendto(sockfd,roll,strlen(roll),0,(struct sockaddr *)&server_addr,sizeof(server_addr));
    recvfrom(sockfd,buffer,sizeof(buffer),0,NULL,NULL);
    printf("\nServer Response:\n%s\n",buffer);
    close(sockfd);
    return 0;
}