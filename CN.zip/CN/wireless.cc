#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/propagation-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/lr-wpan-module.h"
#include "ns3/sixlowpan-module.h"
#include <fstream>
#include <iomanip>
#include <vector>

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("SmartCampus");

struct Rx {
    double sum=0,mn=1e9;
    int n=0;
};

struct Res {
    double avg=0,mn=0,tp=0,dly=0,loss=0,pdr=0;
};

const double T0=2.0;
const double T1=20.0;
const char*names[3]={"WiFi","Bluetooth","Zigbee"};
const double txp[3]={20.0,4.0,0.0};
const double ex[3]={3.0,2.5,3.0};
const char*rate[3]={"4Mbps","200Kbps","40Kbps"};
const uint32_t psz[3]={1024,512,60};
uint32_t seed=1;

Ptr<PropagationLossModel> makeLoss(double e) {
    Ptr<LogDistancePropagationLossModel> m=CreateObject<LogDistancePropagationLossModel>();
    m->SetAttribute("Exponent",DoubleValue(e));
    return m;
}

void sample(Ptr<PropagationLossModel> m,double tx,Ptr<MobilityModel> ap,NodeContainer sta,Rx*r,double end) {
    double p;
    for(uint32_t i=0;i<sta.GetN();i++) {
        p=m->CalcRxPower(tx,sta.Get(i)->GetObject<MobilityModel>(),ap);
        r->sum+=p;
        r->n++;
        if(p<r->mn) r->mn=p;
    }
    if(Simulator::Now().GetSeconds()+0.5<end) Simulator::Schedule(Seconds(0.5),&sample,m,tx,ap,sta,r,end);
}

void mobile(NodeContainer ap,NodeContainer sta,double sp,double area) {
    MobilityHelper mh;
    Ptr<ListPositionAllocator> ca,sa;
    Ptr<UniformRandomVariable> xr,yr;
    Ptr<RandomRectanglePositionAllocator> wp;
    double c=area/2.0;
    ca=CreateObject<ListPositionAllocator>();
    ca->Add(Vector(c,c,0.0));
    mh.SetPositionAllocator(ca);
    mh.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mh.Install(ap);
    sa=CreateObject<ListPositionAllocator>();
    sa->Add(Vector(c+1.0,c,0.0));
    sa->Add(Vector(c,c+1.0,0.0));
    sa->Add(Vector(c-1.0,c,0.0));
    xr=CreateObject<UniformRandomVariable>();
    xr->SetAttribute("Min",DoubleValue(0.0));
    xr->SetAttribute("Max",DoubleValue(area));
    yr=CreateObject<UniformRandomVariable>();
    yr->SetAttribute("Min",DoubleValue(0.0));
    yr->SetAttribute("Max",DoubleValue(area));
    wp=CreateObject<RandomRectanglePositionAllocator>();
    wp->SetX(xr);
    wp->SetY(yr);
    mh.SetPositionAllocator(sa);
    mh.SetMobilityModel("ns3::RandomWaypointMobilityModel",
                        "Speed",StringValue("ns3::ConstantRandomVariable[Constant="+std::to_string(sp)+"]"),
                        "Pause",StringValue("ns3::ConstantRandomVariable[Constant=0.5]"),
                        "PositionAllocator",PointerValue(wp));
    mh.Install(sta);
}

void setupWifi(int k,Ptr<PropagationLossModel> lm,NodeContainer ap,NodeContainer sta,Address&sa,Address&da) {
    YansWifiPhyHelper phy;
    WifiHelper wf;
    WifiMacHelper mac;
    Ssid ss=Ssid("net");
    Ptr<YansWifiChannel> ch=CreateObject<YansWifiChannel>();
    NetDeviceContainer ad,sd;
    InternetStackHelper in;
    Ipv4AddressHelper ip;
    Ipv4InterfaceContainer ai;
    ch->SetPropagationLossModel(lm);
    ch->SetPropagationDelayModel(CreateObject<ConstantSpeedPropagationDelayModel>());
    phy.SetChannel(ch);
    phy.Set("TxPowerStart",DoubleValue(txp[k]));
    phy.Set("TxPowerEnd",DoubleValue(txp[k]));
    if(k==0) {
        wf.SetStandard(WIFI_STANDARD_80211g);
        wf.SetRemoteStationManager("ns3::AarfWifiManager");
    } else {
        wf.SetStandard(WIFI_STANDARD_80211b);
        wf.SetRemoteStationManager("ns3::ConstantRateWifiManager",
                                   "DataMode",StringValue("DsssRate1Mbps"),
                                   "ControlMode",StringValue("DsssRate1Mbps"));
    }
    mac.SetType("ns3::ApWifiMac","Ssid",SsidValue(ss));
    ad=wf.Install(phy,mac,ap);
    mac.SetType("ns3::StaWifiMac","Ssid",SsidValue(ss),"ActiveProbing",BooleanValue(false));
    sd=wf.Install(phy,mac,sta);
    in.Install(ap);
    in.Install(sta);
    ip.SetBase("10.1.1.0","255.255.255.0");
    ai=ip.Assign(ad);
    ip.Assign(sd);
    sa=InetSocketAddress(Ipv4Address::GetAny(),5000+k);
    da=InetSocketAddress(ai.GetAddress(0),5000+k);
}

void setupZigbee(NodeContainer ap,NodeContainer sta,Address&sa,Address&da) {
    NodeContainer all;
    LrWpanHelper lr;
    NetDeviceContainer ld,sd;
    InternetStackHelper in;
    SixLowPanHelper six;
    Ipv6AddressHelper ip;
    Ipv6InterfaceContainer ifs;
    all.Add(ap);
    all.Add(sta);
    ld=lr.Install(all);
    lr.AssociateToPan(ld,10);
    in.SetIpv4StackInstall(false);
    in.Install(all);
    sd=six.Install(ld);
    ip.SetBase(Ipv6Address("2001:1::"),Ipv6Prefix(64));
    ifs=ip.Assign(sd);
    sa=Inet6SocketAddress(Ipv6Address::GetAny(),5002);
    da=Inet6SocketAddress(ifs.GetAddress(0,1),5002);
}

void sendApps(NodeContainer ap,NodeContainer sta,Address sa,Address da,std::string rt,uint32_t sz) {
    PacketSinkHelper sk("ns3::UdpSocketFactory",sa);
    OnOffHelper on("ns3::UdpSocketFactory",da);
    ApplicationContainer a,b;
    a=sk.Install(ap.Get(0));
    a.Start(Seconds(1.0));
    a.Stop(Seconds(T1+1.0));
    on.SetAttribute("DataRate",StringValue(rt));
    on.SetAttribute("PacketSize",UintegerValue(sz));
    on.SetAttribute("OnTime",StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    on.SetAttribute("OffTime",StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    b=on.Install(sta);
    b.Start(Seconds(T0));
    b.Stop(Seconds(T1));
}

Res run(int k,double sp,double area) {
    NodeContainer ap,sta;
    Ptr<PropagationLossModel> lm;
    Address sa,da;
    Rx rx;
    Res r;
    FlowMonitorHelper fh;
    Ptr<FlowMonitor> mon;
    std::map<FlowId,FlowMonitor::FlowStats> st;
    double tx=0,rc=0,rb=0,ds=0;
    RngSeedManager::SetSeed(seed);
    ap.Create(1);
    sta.Create(3);
    lm=makeLoss(ex[k]);
    mobile(ap,sta,sp,area);
    if(k<2) setupWifi(k,lm,ap,sta,sa,da);
    else setupZigbee(ap,sta,sa,da);
    sendApps(ap,sta,sa,da,rate[k],psz[k]);
    Simulator::Schedule(Seconds(T0),&sample,lm,txp[k],ap.Get(0)->GetObject<MobilityModel>(),sta,&rx,T1);
    mon=fh.InstallAll();
    Simulator::Stop(Seconds(T1+1.0));
    Simulator::Run();
    mon->CheckForLostPackets();
    st=mon->GetFlowStats();
    for(auto&f:st) {
        tx+=f.second.txPackets;
        rc+=f.second.rxPackets;
        rb+=f.second.rxBytes;
        ds+=f.second.delaySum.GetSeconds();
    }
    r.tp=rb*8.0/(T1-T0)/1e6;
    r.dly=rc>0?ds/rc*1000.0:0;
    r.pdr=tx>0?rc/tx*100.0:0;
    r.loss=tx>0?100.0-r.pdr:0;
    r.avg=rx.n>0?rx.sum/rx.n:0;
    r.mn=rx.n>0?rx.mn:0;
    Simulator::Destroy();
    return r;
}

int main(int argc,char*argv[]) {
    double sp=0,wa=200.0,za=50.0,ba=20.0,ar;
    std::string out="campus_results.csv";
    std::vector<double> sl={1.0,2.0,5.0,10.0};
    std::ofstream o;
    Res r;
    CommandLine cmd(__FILE__);
    cmd.AddValue("speed","Single node speed in m/s (0 sweeps 1,2,5,10)",sp);
    cmd.AddValue("wifiArea","Wi-Fi roaming square side in m",wa);
    cmd.AddValue("zigbeeArea","Zigbee roaming square side in m",za);
    cmd.AddValue("btArea","Bluetooth-like roaming square side in m",ba);
    cmd.AddValue("seed","RNG seed",seed);
    cmd.AddValue("out","Output CSV file",out);
    cmd.Parse(argc,argv);
    if(sp>0) sl={sp};
    o.open(out);
    o<<"Technology,SpeedMps,AvgRxPowerDbm,MinRxPowerDbm,ThroughputMbps,AvgDelayMs,PacketLossPercent,PDRPercent\n";
    std::cout<<std::fixed<<std::setprecision(3);
    for(double s:sl) {
        std::cout<<"\nSpeed: "<<s<<" m/s\n==========================================\n";
        for(int k=0;k<3;k++) {
            ar=k==0?wa:(k==1?ba:za);
            r=run(k,s,ar);
            std::cout<<names[k]<<":\n";
            std::cout<<"  Avg Rx Power: "<<r.avg<<" dBm\n";
            std::cout<<"  Min Rx Power: "<<r.mn<<" dBm\n";
            std::cout<<"  Throughput  : "<<r.tp<<" Mbps\n";
            std::cout<<"  Avg Delay   : "<<r.dly<<" ms\n";
            std::cout<<"  Packet Loss : "<<r.loss<<" %\n";
            std::cout<<"  PDR         : "<<r.pdr<<" %\n\n";
            o<<names[k]<<","<<s<<","<<r.avg<<","<<r.mn<<","<<r.tp<<","<<r.dly<<","<<r.loss<<","<<r.pdr<<"\n";
        }
    }
    o.close();
    std::cout<<"Saved "<<out<<"\n";
    return 0;
}