#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("TcpUdpSim");

int main(int argc, char *argv[]) {
    // Configurable parameters
    std::string bw="2Mbps";
    std::string udpRate="1Mbps";
    uint32_t qSize=50;
    std::string delay="10ms";

    CommandLine cmd;
    cmd.AddValue("bw","Bottleneck bandwidth",bw);
    cmd.AddValue("udpRate","UDP data rate",udpRate);
    cmd.AddValue("qSize","Queue size",qSize);
    cmd.AddValue("delay","Bottleneck delay",delay);
    cmd.Parse(argc,argv);

    // 6 nodes total
    NodeContainer n0,n1,r0,r1,n2,n3;
    n0.Create(1); n1.Create(1);
    r0.Create(1); r1.Create(1);
    n2.Create(1); n3.Create(1);

    // Access links 10Mbps 2ms
    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate",StringValue("10Mbps"));
    access.SetChannelAttribute("Delay",StringValue("2ms"));

    // Bottleneck link
    PointToPointHelper bottleneck;
    bottleneck.SetDeviceAttribute("DataRate",StringValue(bw));
    bottleneck.SetChannelAttribute("Delay",StringValue(delay));
    bottleneck.SetQueue("ns3::DropTailQueue","MaxSize",
                        QueueSizeValue(QueueSize(QueueSizeUnit::PACKETS,qSize)));

    // Install links
    NetDeviceContainer d_n0r0=access.Install(n0.Get(0),r0.Get(0));
    NetDeviceContainer d_n1r0=access.Install(n1.Get(0),r0.Get(0));
    NetDeviceContainer d_r0r1=bottleneck.Install(r0.Get(0),r1.Get(0));
    NetDeviceContainer d_r1n2=access.Install(r1.Get(0),n2.Get(0));
    NetDeviceContainer d_r1n3=access.Install(r1.Get(0),n3.Get(0));

    // Internet stack
    InternetStackHelper internet;
    internet.Install(n0); internet.Install(n1);
    internet.Install(r0); internet.Install(r1);
    internet.Install(n2); internet.Install(n3);

    // IP addresses
    Ipv4AddressHelper addr;
    addr.SetBase("10.1.1.0","255.255.255.0");
    Ipv4InterfaceContainer i_n0r0=addr.Assign(d_n0r0);
    addr.SetBase("10.1.2.0","255.255.255.0");
    Ipv4InterfaceContainer i_n1r0=addr.Assign(d_n1r0);
    addr.SetBase("10.1.3.0","255.255.255.0");
    Ipv4InterfaceContainer i_r0r1=addr.Assign(d_r0r1);
    addr.SetBase("10.1.4.0","255.255.255.0");
    Ipv4InterfaceContainer i_r1n2=addr.Assign(d_r1n2);
    addr.SetBase("10.1.5.0","255.255.255.0");
    Ipv4InterfaceContainer i_r1n3=addr.Assign(d_r1n3);

    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // TCP: n0 -> n3
    uint16_t tcpPort=8080;
    PacketSinkHelper tcpSink("ns3::TcpSocketFactory",
                              InetSocketAddress(Ipv4Address::GetAny(),tcpPort));
    ApplicationContainer tcpSinkApp=tcpSink.Install(n3.Get(0));
    tcpSinkApp.Start(Seconds(0.0));
    tcpSinkApp.Stop(Seconds(20.0));

    BulkSendHelper tcpSrc("ns3::TcpSocketFactory",
                           InetSocketAddress(i_r1n3.GetAddress(1),tcpPort));
    tcpSrc.SetAttribute("MaxBytes",UintegerValue(0));
    tcpSrc.SetAttribute("SendSize",UintegerValue(1024));
    ApplicationContainer tcpSrcApp=tcpSrc.Install(n0.Get(0));
    tcpSrcApp.Start(Seconds(1.0));
    tcpSrcApp.Stop(Seconds(20.0));

    // UDP: n1 -> n2
    uint16_t udpPort=9090;
    PacketSinkHelper udpSink("ns3::UdpSocketFactory",
                              InetSocketAddress(Ipv4Address::GetAny(),udpPort));
    ApplicationContainer udpSinkApp=udpSink.Install(n2.Get(0));
    udpSinkApp.Start(Seconds(0.0));
    udpSinkApp.Stop(Seconds(20.0));

    OnOffHelper udpSrc("ns3::UdpSocketFactory",
                        InetSocketAddress(i_r1n2.GetAddress(1),udpPort));
    udpSrc.SetAttribute("DataRate",StringValue(udpRate));
    udpSrc.SetAttribute("PacketSize",UintegerValue(512));
    udpSrc.SetAttribute("OnTime",StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    udpSrc.SetAttribute("OffTime",StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer udpSrcApp=udpSrc.Install(n1.Get(0));
    udpSrcApp.Start(Seconds(1.0));
    udpSrcApp.Stop(Seconds(20.0));

    // Enable tracing
    AsciiTraceHelper ascii;
    bottleneck.EnableAsciiAll(ascii.CreateFileStream("tcp-udp-sim.tr"));
    bottleneck.EnablePcapAll("tcp-udp-sim");

    // FlowMonitor
    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor=flowmon.InstallAll();

    Simulator::Stop(Seconds(20.0));
    Simulator::Run();

    // Results
    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier=
        DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    std::map<FlowId,FlowMonitor::FlowStats> stats=monitor->GetFlowStats();

    std::cout<<"\n=== Results ==="<<std::endl;
    std::cout<<"Bottleneck BW: "<<bw
             <<" | UDP Rate: "<<udpRate
             <<" | Queue: "<<qSize
             <<" | Delay: "<<delay<<std::endl;

    for(auto &s:stats) {
        Ipv4FlowClassifier::FiveTuple t=classifier->FindFlow(s.first);
        std::string proto=(t.protocol==6)?"TCP":"UDP";
        double dur=s.second.timeLastRxPacket.GetSeconds()
                  -s.second.timeFirstTxPacket.GetSeconds();
        double tp=(dur>0)?(s.second.rxBytes*8.0/dur/1e6):0;
        double delay_avg=(s.second.rxPackets>0)?
            (s.second.delaySum.GetSeconds()/s.second.rxPackets):0;
        uint64_t lost=s.second.txPackets-s.second.rxPackets;

        std::cout<<"["<<proto<<"] "
                 <<t.sourceAddress<<" -> "<<t.destinationAddress<<std::endl;
        std::cout<<"  Throughput : "<<tp<<" Mbps"<<std::endl;
        std::cout<<"  Avg Delay  : "<<delay_avg*1000<<" ms"<<std::endl;
        std::cout<<"  Lost Pkts  : "<<lost<<std::endl;
        std::cout<<"  Tx Packets : "<<s.second.txPackets<<std::endl;
        std::cout<<"  Rx Packets : "<<s.second.rxPackets<<std::endl;
    }

    Simulator::Destroy();
    return 0;
}
