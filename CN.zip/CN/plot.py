import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("whitegrid")
plt.rcParams["font.family"]="Times New Roman"
plt.rcParams["font.size"]=15
plt.rcParams["axes.labelweight"]="bold"
df=pd.read_csv("routing_results.csv")
metrics=[("ThroughputMbps","Throughput","Mbps"),("PacketLossPercent","Packet Loss","%"),("PDRPercent","Packet Delivery Ratio","%"),("TransmissionRatioPercent","Transmission Ratio","%"),("EndToEndDelayMs","End-to-End Delay","ms")]
for col,title,unit in metrics:
    fig,ax=plt.subplots(figsize=(8,5),dpi=150)
    df.pivot(index="Protocol",columns="Condition",values=col).plot.bar(ax=ax,rot=0)
    ax.set_title("Routing Comparison - "+title)
    ax.set_xlabel("Protocol")
    ax.set_ylabel(unit)
    plt.tight_layout()
    name="routing"+col+".png"
    plt.savefig(name,dpi=150)
    plt.show()
    plt.close(fig)
    print("Graph saved:",name)