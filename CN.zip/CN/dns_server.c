#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

typedef struct {
    char domain[100];
    char ip[20];
} DNS;

//DNS Table
DNS db[]={
    {"google.com","142.250.190.78"},
    {"youtube.com","142.250.190.110"},
    {"github.com","140.82.121.4"},
    {"facebook.com","157.240.241.35"},
    {"amazon.com","205.251.242.103"}
};
int db_size=5;

int main() {
    int sockfd;
    struct sockaddr_in server_addr,client_addr;
    socklen_t len=sizeof(client_addr);
    char domain[100],reply[100];

    sockfd=socket(AF_INET,SOCK_DGRAM,0);
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=INADDR_ANY;
    server_addr.sin_port=htons(8888); //Default port for DNS

    bind(sockfd,(struct sockaddr *)&server_addr,sizeof(server_addr));
    printf("DNS Server running on port 8888...\n");

    while(1) {
        memset(domain,0,sizeof(domain));
        memset(reply,0,sizeof(reply));

        recvfrom(sockfd,domain,sizeof(domain),0,(struct sockaddr *)&client_addr,&len);
        printf("Query received: %s\n",domain);

        if(strlen(domain)==0||strchr(domain,'.')==NULL) { //Invalid format
            strcpy(reply,"ERROR: Invalid format");
        } else {
            int found=0;
            for(int i=0;i<db_size;i++) {
                if(strcmp(db[i].domain,domain)==0) { //Domain Name to IP address mapping
                    strcpy(reply,db[i].ip);
                    found=1;
                    break;
                }
            }
            if(!found) strcpy(reply,"NXDOMAIN"); //Non - Existent Domain
        }

        printf("Response sent: %s\n",reply);
        sendto(sockfd,reply,strlen(reply),0,(struct sockaddr *)&client_addr,len);
    }

    close(sockfd);
    return 0;
}
