#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define GEN "10011"
#define GEN_LEN 5

void xor(char *a,char *b,int len) {
    for(int i=0;i<len;i++)
        a[i]=(a[i]==b[i])?'0':'1';
}

int check_crc(char *frame) {
    int flen=strlen(frame);
    char temp[200];
    strcpy(temp,frame);
    char div[GEN_LEN+1];
    strncpy(div,temp,GEN_LEN);
    div[GEN_LEN]='\0';
    for(int i=GEN_LEN;i<=flen;i++) {
        if(div[0]=='1') xor(div,(char *)GEN,GEN_LEN);
        else xor(div,"00000",GEN_LEN);
        if(i<flen) {
            memmove(div,div+1,GEN_LEN-1);
            div[GEN_LEN-1]=temp[i];
            div[GEN_LEN]='\0';
        }
    }
    for(int i=1;i<GEN_LEN;i++)
        if(div[i]!='0') return 0;
    return 1;
}

int main() {
    int sockfd;
    struct sockaddr_in addr;
    char frame[200];
    int introduce_error;

    sockfd=socket(AF_INET,SOCK_STREAM,0);
    addr.sin_family=AF_INET;
    addr.sin_port=htons(9091);
    inet_pton(AF_INET,"127.0.0.1",&addr.sin_addr);
    connect(sockfd,(struct sockaddr *)&addr,sizeof(addr));

    recv(sockfd,frame,sizeof(frame),0);
    printf("Received Frame: %s\n",frame);

    printf("Introduce error? (1=Yes 0=No): ");
    scanf("%d",&introduce_error);
    if(introduce_error) {
        frame[2]=(frame[2]=='0')?'1':'0';
        printf("Error introduced! Frame now: %s\n",frame);
    }

    printf("\n--- CRC Verification ---\n");
    if(check_crc(frame))
        printf("Result: No error. Frame is valid.\n");
    else
        printf("Result: ERROR detected! Frame is corrupted.\n");

    close(sockfd);
    return 0;
}
