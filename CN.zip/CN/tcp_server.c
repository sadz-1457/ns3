#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

void *clients(void *arg) {
    int client_fd=*(int *)arg;
    char roll[20],line[200],reply[200];
    read(client_fd,roll,sizeof(roll));
    FILE *fp=fopen("students.csv","r");
    int found=0;
    while(fgets(line,sizeof(line),fp)) {
        char temp[200];
        strcpy(temp,line);
        char *token=strtok(temp,",");
        if(strcmp(token,roll)==0) {
            strcpy(reply,line);
            found=1;
            break;
        }
    }
    fclose(fp);
    if(found)
        write(client_fd,reply,strlen(reply));
    else
        write(client_fd,"Student Record Not Found",24);
    close(client_fd);
    return NULL;
}

int main() {
    int server_fd,client_fd;
    struct sockaddr_in server_addr;
    pthread_t tid;
    server_fd=socket(AF_INET,SOCK_STREAM,0);
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=INADDR_ANY;
    server_addr.sin_port=htons(8080);
    bind(server_fd,(struct sockaddr *)&server_addr,sizeof(server_addr));
    listen(server_fd,4);
    printf("Server Waiting for Clients...\n");
    while(1) {
        client_fd=accept(server_fd,NULL,NULL);
        printf("Client Connected\n");
        pthread_create(&tid,NULL,clients,&client_fd);
        pthread_detach(tid);
    }
    close(server_fd);
    return 0;
}
