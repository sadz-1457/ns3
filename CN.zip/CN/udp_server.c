#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int sockfd;
    struct sockaddr_in server_addr,client_addr;
    socklen_t len=sizeof(client_addr);
    char roll[20],line[200],reply[100];
    sockfd=socket(AF_INET,SOCK_DGRAM,0);
    server_addr.sin_family=AF_INET;
    server_addr.sin_addr.s_addr=INADDR_ANY;
    server_addr.sin_port=htons(8080);
    bind(sockfd,(struct sockaddr *)&server_addr,sizeof(server_addr));
    printf("Waiting for Client Request...\n");
    recvfrom(sockfd,roll,sizeof(roll),0,(struct sockaddr *)&client_addr,&len);
    FILE *fp=fopen("students.csv","r");
    int found=0;
    while(fgets(line,sizeof(line),fp)) {
        char temp[200];
        strcpy(temp,line);
        char *r=strtok(temp,",");
        char *name=strtok(NULL,",");
        if(strcmp(r,roll)==0) {
            sprintf(reply,"Roll: %s\nName: %s",r,name);
            found=1;
            break;
        }
    }
    fclose(fp);
    if(!found)
        strcpy(reply,"Student Record Not Found");
    sendto(sockfd,reply,strlen(reply),0,(struct sockaddr *)&client_addr,len);
    close(sockfd);
    return 0;
}
