#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("TCPCongestion");

int main(int argc, char *argv[]) {
    std::string tcp="reno";

    CommandLine cmd;
    cmd.AddValue("tcp","TCP variant (reno/cubic/bbr)",tcp);
    cmd.Parse(argc,argv);

    std::string tcpType;
    if(tcp=="reno") tcpType="TcpNewReno";
    else if(tcp=="cubic") tcpType="TcpCubic";
    else if(tcp=="bbr") tcpType="TcpBbr";
    else {
        std::cout<<"Unknown TCP type. Use reno, cubic or bbr\n";
        return 1;
    }

    Config::SetDefault("ns3::TcpL4Protocol::SocketType",StringValue("ns3::"+tcpType));

    // 5 vehicles + 1 router + 1 server
    NodeContainer vehicles,router,server;
    vehicles.Create(5);
    router.Create(1);
    server.Create(1);

    // Access links: vehicles to router
    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate",StringValue("10Mbps"));
    access.SetChannelAttribute("Delay",StringValue("2ms"));

    // Bottleneck: router to server — creates congestion
    PointToPointHelper bottleneck;
    bottleneck.SetDeviceAttribute("DataRate",StringValue("2Mbps"));
    bottleneck.SetChannelAttribute("Delay",StringValue("20ms"));
    bottleneck.SetQueue("ns3::DropTailQueue","MaxSize",
                        QueueSizeValue(QueueSize(QueueSizeUnit::PACKETS,20)));

    // Connect vehicles to router
    NetDeviceContainer dv[5];
    for(int i=0;i<5;i++)
        dv[i]=access.Install(vehicles.Get(i),router.Get(0));

    // Connect router to server
    NetDeviceContainer dr=bottleneck.Install(router.Get(0),server.Get(0));

    // Internet stack
    InternetStackHelper internet;
    internet.Install(vehicles);
    internet.Install(router);
    internet.Install(server);

    // IP addresses
    Ipv4AddressHelper addr;
    Ipv4InterfaceContainer iv[5];
    for(int i=0;i<5;i++) {
        std::string base="10.1."+std::to_string(i+1)+".0";
        addr.SetBase(base.c_str(),"255.255.255.0");
        iv[i]=addr.Assign(dv[i]);
    }
    addr.SetBase("10.1.6.0","255.255.255.0");
    Ipv4InterfaceContainer ir=addr.Assign(dr);

    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    // Server sink — one sink handles all 5 flows on same port
    uint16_t port=8080;
    PacketSinkHelper sink("ns3::TcpSocketFactory",
                          InetSocketAddress(Ipv4Address::GetAny(),port));
    ApplicationContainer sinkApp=sink.Install(server.Get(0));
    sinkApp.Start(Seconds(0.0));
    sinkApp.Stop(Seconds(20.0));

    // 5 TCP senders — one per vehicle
    for(int i=0;i<5;i++) {
        BulkSendHelper src("ns3::TcpSocketFactory",
                           InetSocketAddress(ir.GetAddress(1),port));
        src.SetAttribute("MaxBytes",UintegerValue(0));
        src.SetAttribute("SendSize",UintegerValue(1024));
        ApplicationContainer srcApp=src.Install(vehicles.Get(i));
        srcApp.Start(Seconds(1.0+i*0.5));
        srcApp.Stop(Seconds(20.0));
    }

    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor=flowmon.InstallAll();

    Simulator::Stop(Seconds(20.0));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier=
        DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    std::map<FlowId,FlowMonitor::FlowStats> stats=monitor->GetFlowStats();

    std::cout<<"\nTCP Variant: "<<tcp<<"\n";
    std::cout<<"==========================================\n";

    double totalTp=0,sumTp=0,sumTpSq=0;
    int flowCount=0;

    for(auto &s:stats) {
        Ipv4FlowClassifier::FiveTuple t=classifier->FindFlow(s.first);
        // Only count vehicle->server flows (src port side)
        if(t.protocol!=6) continue;
        if(t.destinationPort!=port) continue;

        double dur=s.second.timeLastRxPacket.GetSeconds()
                  -s.second.timeFirstTxPacket.GetSeconds();
        double tp=(dur>0)?(s.second.rxBytes*8.0/dur/1e6):0;
        double avgDelay=(s.second.rxPackets>0)?
            (s.second.delaySum.GetSeconds()/s.second.rxPackets*1000):0;
        uint64_t lost=s.second.txPackets-s.second.rxPackets;

        flowCount++;
        totalTp+=tp;
        sumTp+=tp;
        sumTpSq+=tp*tp;

        std::cout<<"Flow "<<flowCount<<": "
                 <<t.sourceAddress<<" -> "<<t.destinationAddress<<"\n";
        std::cout<<"  Throughput : "<<tp<<" Mbps\n";
        std::cout<<"  Avg Delay  : "<<avgDelay<<" ms\n";
        std::cout<<"  Lost Pkts  : "<<lost<<"\n";
        std::cout<<"  Tx Packets : "<<s.second.txPackets<<"\n";
        std::cout<<"  Rx Packets : "<<s.second.rxPackets<<"\n\n";
    }

    double fairness=(flowCount>0&&sumTpSq>0)?
        (sumTp*sumTp)/(flowCount*sumTpSq):0;

    std::cout<<"==========================================\n";
    std::cout<<"Total Throughput : "<<totalTp<<" Mbps\n";
    std::cout<<"Fairness Index   : "<<fairness<<"\n";

    Simulator::Destroy();
    return 0;
}
