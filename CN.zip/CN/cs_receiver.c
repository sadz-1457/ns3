#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int sockfd;
    struct sockaddr_in addr;
    char msg[100];
    unsigned char data[100];
    unsigned short cs;
    int introduce_error;

    sockfd=socket(AF_INET,SOCK_STREAM,0);
    addr.sin_family=AF_INET;
    addr.sin_port=htons(9090);
    inet_pton(AF_INET,"127.0.0.1",&addr.sin_addr);
    connect(sockfd,(struct sockaddr *)&addr,sizeof(addr));

    int len=0;
    while(1){
        recv(sockfd,&msg[len],1,0);
        if (msg[len]=='\0'){
            break;
        }
        len++;
    }
    recv(sockfd,&cs,sizeof(cs),0);

    printf("Received Message: %s\n",msg);
    printf("Received Checksum: %d\n",cs);

    printf("Introduce error? (1=Yes 0=No): ");
    scanf("%d",&introduce_error);
    if(introduce_error) {
        msg[0]^=0xFF;
        printf("Error introduced! Data corrupted.\n");
    }

    for(int i=0;i<len;i++) data[i]=(unsigned char)msg[i];

    unsigned int sum=cs;
    for(int i=0;i<len;i++) {
        sum+=data[i];
        while (sum>0xFF) sum=(sum&0xFF)+(sum>>8);
    }

    printf("\n--- Verification ---\n");
    printf("Final sum: %d\n",sum);
    if((~sum&0xFF)==0)
        printf("Result: No error. Data is valid.\n");
    else
        printf("Result: ERROR detected! Data is corrupted.\n");

    close(sockfd);
    return 0;
}
