import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_style("whitegrid")
plt.rcParams["font.family"]="Times New Roman"
plt.rcParams["font.size"]=15
plt.rcParams["axes.labelweight"]="bold"
df=pd.read_csv("campus_results.csv")
metrics=[("AvgRxPowerDbm","Average Rx Power","dBm"),("ThroughputMbps","Throughput","Mbps"),("AvgDelayMs","Average Delay","ms"),("PacketLossPercent","Packet Loss","%"),("PDRPercent","Packet Delivery Ratio","%")]
for col,title,unit in metrics:
    fig=plt.figure(figsize=(8,5),dpi=150)
    for tech,g in df.groupby("Technology"):
        plt.plot(g["SpeedMps"],g[col],marker="o",label=tech)
    plt.title("Wireless Comparison - "+title)
    plt.xlabel("Speed (m/s)")
    plt.ylabel(unit)
    plt.legend()
    plt.tight_layout()
    name="wireless"+col+".png"
    plt.savefig(name,dpi=150)
    plt.show()
    plt.close(fig)
    print("Graph saved:",name)