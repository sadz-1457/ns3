#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("UdpLatency");

int main(int argc, char *argv[]) {
    std::string latency="2ms";

    // Accept latency from command line
    CommandLine cmd;
    cmd.AddValue("latency","Link latency",latency);
    cmd.Parse(argc,argv);

    // Two nodes
    NodeContainer nodes;
    nodes.Create(2);

    // P2P link
    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate",StringValue("5Mbps"));
    p2p.SetChannelAttribute("Delay",StringValue(latency));
    NetDeviceContainer devices=p2p.Install(nodes.Get(0),nodes.Get(1));

    // Internet stack
    InternetStackHelper internet;
    internet.Install(nodes);

    // IP addresses
    Ipv4AddressHelper addr;
    addr.SetBase("10.1.1.0","255.255.255.0");
    Ipv4InterfaceContainer iface=addr.Assign(devices);

    // Flow 1 server port 5000
    UdpServerHelper srv1(5000);
    ApplicationContainer srvApp1=srv1.Install(nodes.Get(1));
    srvApp1.Start(Seconds(1.0));
    srvApp1.Stop(Seconds(10.0));

    // Flow 1 client port 5000
    UdpClientHelper cli1(iface.GetAddress(1),5000);
    cli1.SetAttribute("MaxPackets",UintegerValue(100000));
    cli1.SetAttribute("Interval",TimeValue(MicroSeconds(500)));
    cli1.SetAttribute("PacketSize",UintegerValue(1024));
    ApplicationContainer cliApp1=cli1.Install(nodes.Get(0));
    cliApp1.Start(Seconds(2.0));
    cliApp1.Stop(Seconds(10.0));

    // Flow 2 server port 6000
    UdpServerHelper srv2(6000);
    ApplicationContainer srvApp2=srv2.Install(nodes.Get(1));
    srvApp2.Start(Seconds(1.0));
    srvApp2.Stop(Seconds(10.0));

    // Flow 2 client port 6000
    UdpClientHelper cli2(iface.GetAddress(1),6000);
    cli2.SetAttribute("MaxPackets",UintegerValue(100000));
    cli2.SetAttribute("Interval",TimeValue(MicroSeconds(1000)));
    cli2.SetAttribute("PacketSize",UintegerValue(1024));
    ApplicationContainer cliApp2=cli2.Install(nodes.Get(0));
    cliApp2.Start(Seconds(2.0));
    cliApp2.Stop(Seconds(10.0));

    // PCAP trace
    p2p.EnablePcapAll("udp-latency");

    Simulator::Stop(Seconds(10.0));
    Simulator::Run();

    // Flow 1 results
    Ptr<UdpServer> s1=DynamicCast<UdpServer>(srvApp1.Get(0));
    uint64_t rx1=s1->GetReceived()*1024;
    double tp1=(rx1*8.0)/(8.0*1e6);

    // Flow 2 results
    Ptr<UdpServer> s2=DynamicCast<UdpServer>(srvApp2.Get(0));
    uint64_t rx2=s2->GetReceived()*1024;
    double tp2=(rx2*8.0)/(8.0*1e6);

    std::cout<<"Latency: "<<latency<<std::endl;
    std::cout<<"Flow 1 (Port 5000): "<<rx1<<" bytes | Throughput: "<<tp1<<" Mbps"<<std::endl;
    std::cout<<"Flow 2 (Port 6000): "<<rx2<<" bytes | Throughput: "<<tp2<<" Mbps"<<std::endl;

    Simulator::Destroy();
    return 0;
}
