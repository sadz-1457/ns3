#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/csma-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/aodv-helper.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("RoutingComparison");

int main(int argc, char *argv[]) {
    std::string protocol="rip";
    std::string condition="normal";

    CommandLine cmd;
    cmd.AddValue("protocol","Routing protocol (rip/ospf/aodv)",protocol);
    cmd.AddValue("condition","Network condition (normal/congestion/failure)",condition);
    cmd.Parse(argc,argv);

    NodeContainer src,r,dst;
    src.Create(2);
    r.Create(3);
    dst.Create(2);

    InternetStackHelper internet;

    if(protocol=="rip") {
        RipHelper rip;
        internet.SetRoutingHelper(rip);
    } else if(protocol=="aodv") {
        AodvHelper aodv;
        internet.SetRoutingHelper(aodv);
    }

    internet.Install(src);
    internet.Install(r);
    internet.Install(dst);

    CsmaHelper csma;
    csma.SetChannelAttribute("DataRate",StringValue("10Mbps"));
    csma.SetChannelAttribute("Delay",StringValue("2ms"));

    NodeContainer n_s0r0;
    n_s0r0.Add(src.Get(0)); n_s0r0.Add(r.Get(0));
    NetDeviceContainer d_s0r0=csma.Install(n_s0r0);

    NodeContainer n_s1r0;
    n_s1r0.Add(src.Get(1)); n_s1r0.Add(r.Get(0));
    NetDeviceContainer d_s1r0=csma.Install(n_s1r0);

    NodeContainer n_r0r1;
    n_r0r1.Add(r.Get(0)); n_r0r1.Add(r.Get(1));
    NetDeviceContainer d_r0r1=csma.Install(n_r0r1);

    NodeContainer n_r0r2;
    n_r0r2.Add(r.Get(0)); n_r0r2.Add(r.Get(2));
    NetDeviceContainer d_r0r2=csma.Install(n_r0r2);

    NodeContainer n_r1d0;
    n_r1d0.Add(r.Get(1)); n_r1d0.Add(dst.Get(0));
    NetDeviceContainer d_r1d0=csma.Install(n_r1d0);

    NodeContainer n_r2d1;
    n_r2d1.Add(r.Get(2)); n_r2d1.Add(dst.Get(1));
    NetDeviceContainer d_r2d1=csma.Install(n_r2d1);

    Ipv4AddressHelper addr;
    addr.SetBase("10.1.1.0","255.255.255.0");
    Ipv4InterfaceContainer i_s0r0=addr.Assign(d_s0r0);
    addr.SetBase("10.1.2.0","255.255.255.0");
    Ipv4InterfaceContainer i_s1r0=addr.Assign(d_s1r0);
    addr.SetBase("10.1.3.0","255.255.255.0");
    Ipv4InterfaceContainer i_r0r1=addr.Assign(d_r0r1);
    addr.SetBase("10.1.4.0","255.255.255.0");
    Ipv4InterfaceContainer i_r0r2=addr.Assign(d_r0r2);
    addr.SetBase("10.1.5.0","255.255.255.0");
    Ipv4InterfaceContainer i_r1d0=addr.Assign(d_r1d0);
    addr.SetBase("10.1.6.0","255.255.255.0");
    Ipv4InterfaceContainer i_r2d1=addr.Assign(d_r2d1);

    if(protocol=="ospf")
        Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    uint16_t port=5000;

    PacketSinkHelper sink("ns3::UdpSocketFactory",
                          InetSocketAddress(Ipv4Address::GetAny(),port));
    ApplicationContainer sinkApp0=sink.Install(dst.Get(0));
    ApplicationContainer sinkApp1=sink.Install(dst.Get(1));
    sinkApp0.Start(Seconds(1.0)); sinkApp0.Stop(Seconds(30.0));
    sinkApp1.Start(Seconds(1.0)); sinkApp1.Stop(Seconds(30.0));

    OnOffHelper flow1("ns3::UdpSocketFactory",
                      InetSocketAddress(i_r1d0.GetAddress(1),port));
    flow1.SetAttribute("DataRate",StringValue("1Mbps"));
    flow1.SetAttribute("PacketSize",UintegerValue(512));
    flow1.SetAttribute("OnTime",StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    flow1.SetAttribute("OffTime",StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer app1=flow1.Install(src.Get(0));
    app1.Start(Seconds(5.0)); app1.Stop(Seconds(30.0));

    OnOffHelper flow2("ns3::UdpSocketFactory",
                      InetSocketAddress(i_r2d1.GetAddress(1),port));
    flow2.SetAttribute("DataRate",StringValue("1Mbps"));
    flow2.SetAttribute("PacketSize",UintegerValue(512));
    flow2.SetAttribute("OnTime",StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    flow2.SetAttribute("OffTime",StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer app2=flow2.Install(src.Get(1));
    app2.Start(Seconds(5.0)); app2.Stop(Seconds(30.0));

    if(condition=="congestion") {
        OnOffHelper extra1("ns3::UdpSocketFactory",
                           InetSocketAddress(i_r1d0.GetAddress(1),port+1));
        extra1.SetAttribute("DataRate",StringValue("5Mbps"));
        extra1.SetAttribute("PacketSize",UintegerValue(512));
        extra1.SetAttribute("OnTime",StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        extra1.SetAttribute("OffTime",StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        ApplicationContainer eapp1=extra1.Install(src.Get(0));
        eapp1.Start(Seconds(5.0)); eapp1.Stop(Seconds(30.0));

        OnOffHelper extra2("ns3::UdpSocketFactory",
                           InetSocketAddress(i_r2d1.GetAddress(1),port+2));
        extra2.SetAttribute("DataRate",StringValue("5Mbps"));
        extra2.SetAttribute("PacketSize",UintegerValue(512));
        extra2.SetAttribute("OnTime",StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        extra2.SetAttribute("OffTime",StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        ApplicationContainer eapp2=extra2.Install(src.Get(1));
        eapp2.Start(Seconds(5.0)); eapp2.Stop(Seconds(30.0));
    }

    if(condition=="failure") {
        Ptr<NetDevice> dev=d_r0r1.Get(0);
        Ptr<Ipv4> ipv4=r.Get(0)->GetObject<Ipv4>();
        int32_t iface=ipv4->GetInterfaceForDevice(dev);
        Simulator::Schedule(Seconds(10.0),&Ipv4::SetDown,ipv4,iface);
    }

    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor=flowmon.InstallAll();

    Simulator::Stop(Seconds(30.0));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier=
        DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    std::map<FlowId,FlowMonitor::FlowStats> stats=monitor->GetFlowStats();

    std::cout<<"\nProtocol: "<<protocol<<" | Condition: "<<condition<<"\n";
    std::cout<<"==========================================\n";

    double totalTx=0,totalRx=0,totalDelay=0,totalPkts=0;
    int fc=0;

    for(auto &s:stats) {
        Ipv4FlowClassifier::FiveTuple t=classifier->FindFlow(s.first);
        if(t.protocol!=17) continue;
        if(t.destinationPort!=port&&t.destinationPort!=port+1&&t.destinationPort!=port+2) continue;

        double dur=s.second.timeLastRxPacket.GetSeconds()
                  -s.second.timeFirstTxPacket.GetSeconds();
        double tp=(dur>0)?(s.second.rxBytes*8.0/dur/1e6):0;
        double avgDelay=(s.second.rxPackets>0)?
            (s.second.delaySum.GetSeconds()/s.second.rxPackets*1000):0;
        double pdr=(s.second.txPackets>0)?
            ((double)s.second.rxPackets/s.second.txPackets*100):0;

        totalTx+=s.second.txPackets;
        totalRx+=s.second.rxPackets;
        totalDelay+=s.second.delaySum.GetSeconds();
        totalPkts+=s.second.rxPackets;
        fc++;

        std::cout<<"Flow "<<fc<<": "
                 <<t.sourceAddress<<" -> "<<t.destinationAddress<<"\n";
        std::cout<<"  Throughput : "<<tp<<" Mbps\n";
        std::cout<<"  Avg Delay  : "<<avgDelay<<" ms\n";
        std::cout<<"  PDR        : "<<pdr<<" %\n";
        std::cout<<"  Tx Packets : "<<s.second.txPackets<<"\n";
        std::cout<<"  Rx Packets : "<<s.second.rxPackets<<"\n\n";
    }

    double overallPDR=(totalTx>0)?(totalRx/totalTx*100):0;
    double overallDelay=(totalPkts>0)?(totalDelay/totalPkts*1000):0;

    std::cout<<"==========================================\n";
    std::cout<<"Overall PDR        : "<<overallPDR<<" %\n";
    std::cout<<"Overall Avg Delay  : "<<overallDelay<<" ms\n";

    Simulator::Destroy();
    return 0;
}