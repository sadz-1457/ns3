#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/propagation-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"

using namespace ns3;

NS_LOG_COMPONENT_DEFINE("SmartCampus");

struct RxStat {
    double sum = 0.0;
    double minV = 1e9;
    int n = 0;
};

// Samples received power (dBm) between a station and its AP every 0.5 s
void SampleRx(Ptr<PropagationLossModel> model, double txDbm,
              Ptr<MobilityModel> ap, Ptr<MobilityModel> sta, RxStat *st) {
    double rx = model->CalcRxPower(txDbm, sta, ap);
    st->sum += rx;
    st->n++;
    if (rx < st->minV) st->minV = rx;
    if (Simulator::Now().GetSeconds() < 19.6) {
        Simulator::Schedule(Seconds(0.5), &SampleRx, model, txDbm, ap, sta, st);
    }
}

Ptr<PropagationLossModel> MakeLoss(double exponent) {
    Ptr<LogDistancePropagationLossModel> m = CreateObject<LogDistancePropagationLossModel>();
    m->SetAttribute("Exponent", DoubleValue(exponent));
    return m;
}

int main(int argc, char *argv[]) {
    double speed = 1.0;
    double area = 200.0;
    CommandLine cmd;
    cmd.AddValue("speed", "Node speed in m/s", speed);
    cmd.AddValue("area", "Side of the square roaming area in m", area);
    cmd.Parse(argc, argv);

    double c = area / 2.0;
    const double appTime = 18.0;   // apps run from 2 s to 20 s

    NodeContainer wifiAp, wifiSta;
    wifiAp.Create(1);
    wifiSta.Create(3);

    NodeContainer btAp, btSta;
    btAp.Create(1);
    btSta.Create(3);

    NodeContainer zgAp, zgSta;
    zgAp.Create(1);
    zgSta.Create(3);

    // ---------- WiFi ----------
    YansWifiChannelHelper wifiChan = YansWifiChannelHelper::Default();
    YansWifiPhyHelper wifiPhy;
    wifiPhy.SetChannel(wifiChan.Create());
    wifiPhy.Set("TxPowerStart", DoubleValue(20.0));
    wifiPhy.Set("TxPowerEnd", DoubleValue(20.0));

    WifiHelper wifi;
    wifi.SetStandard(WIFI_STANDARD_80211g);
    wifi.SetRemoteStationManager("ns3::AarfWifiManager");

    WifiMacHelper wifiMac;
    Ssid ssid1 = Ssid("wifi-net");
    wifiMac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid1));
    NetDeviceContainer wifiApDev = wifi.Install(wifiPhy, wifiMac, wifiAp);
    wifiMac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid1), "ActiveProbing", BooleanValue(false));
    NetDeviceContainer wifiStaDev = wifi.Install(wifiPhy, wifiMac, wifiSta);

    // ---------- Bluetooth ----------
    YansWifiChannelHelper btChan;
    btChan.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    btChan.AddPropagationLoss("ns3::LogDistancePropagationLossModel", "Exponent", DoubleValue(2.5));
    YansWifiPhyHelper btPhy;
    btPhy.SetChannel(btChan.Create());
    btPhy.Set("TxPowerStart", DoubleValue(5.0));
    btPhy.Set("TxPowerEnd", DoubleValue(5.0));

    WifiHelper bt;
    bt.SetStandard(WIFI_STANDARD_80211b);
    bt.SetRemoteStationManager("ns3::ConstantRateWifiManager", "DataMode", StringValue("DsssRate1Mbps"));

    WifiMacHelper btMac;
    Ssid ssid2 = Ssid("bt-net");
    btMac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid2));
    NetDeviceContainer btApDev = bt.Install(btPhy, btMac, btAp);
    btMac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid2), "ActiveProbing", BooleanValue(false));
    NetDeviceContainer btStaDev = bt.Install(btPhy, btMac, btSta);

    // ---------- Zigbee ----------
    YansWifiChannelHelper zgChan;
    zgChan.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");
    zgChan.AddPropagationLoss("ns3::LogDistancePropagationLossModel", "Exponent", DoubleValue(3.0));
    YansWifiPhyHelper zgPhy;
    zgPhy.SetChannel(zgChan.Create());
    zgPhy.Set("TxPowerStart", DoubleValue(10.0));
    zgPhy.Set("TxPowerEnd", DoubleValue(10.0));

    WifiHelper zg;
    zg.SetStandard(WIFI_STANDARD_80211b);
    zg.SetRemoteStationManager("ns3::ConstantRateWifiManager", "DataMode", StringValue("DsssRate1Mbps"));

    WifiMacHelper zgMac;
    Ssid ssid3 = Ssid("zg-net");
    zgMac.SetType("ns3::ApWifiMac", "Ssid", SsidValue(ssid3));
    NetDeviceContainer zgApDev = zg.Install(zgPhy, zgMac, zgAp);
    zgMac.SetType("ns3::StaWifiMac", "Ssid", SsidValue(ssid3), "ActiveProbing", BooleanValue(false));
    NetDeviceContainer zgStaDev = zg.Install(zgPhy, zgMac, zgSta);

    // ---------- Internet stack ----------
    InternetStackHelper internet;
    internet.Install(wifiAp); internet.Install(wifiSta);
    internet.Install(btAp); internet.Install(btSta);
    internet.Install(zgAp); internet.Install(zgSta);

    Ipv4AddressHelper addr;
    addr.SetBase("10.1.1.0", "255.255.255.0");
    Ipv4InterfaceContainer wifiApIf = addr.Assign(wifiApDev);
    addr.Assign(wifiStaDev);

    addr.SetBase("10.1.2.0", "255.255.255.0");
    Ipv4InterfaceContainer btApIf = addr.Assign(btApDev);
    addr.Assign(btStaDev);

    addr.SetBase("10.1.3.0", "255.255.255.0");
    Ipv4InterfaceContainer zgApIf = addr.Assign(zgApDev);
    addr.Assign(zgStaDev);

    // ---------- Mobility ----------
    MobilityHelper mob;

    Ptr<ListPositionAllocator> apPos = CreateObject<ListPositionAllocator>();
    apPos->Add(Vector(c, c, 0.0));
    mob.SetPositionAllocator(apPos);
    mob.SetMobilityModel("ns3::ConstantPositionMobilityModel");
    mob.Install(wifiAp);
    mob.Install(btAp);
    mob.Install(zgAp);

    auto installSta = [&](NodeContainer &nodes) {
        Ptr<ListPositionAllocator> startPos = CreateObject<ListPositionAllocator>();
        startPos->Add(Vector(c + 1.0, c, 0.0));
        startPos->Add(Vector(c, c + 1.0, 0.0));
        startPos->Add(Vector(c - 1.0, c, 0.0));

        Ptr<UniformRandomVariable> xRand = CreateObject<UniformRandomVariable>();
        xRand->SetAttribute("Min", DoubleValue(0.0));
        xRand->SetAttribute("Max", DoubleValue(area));
        Ptr<UniformRandomVariable> yRand = CreateObject<UniformRandomVariable>();
        yRand->SetAttribute("Min", DoubleValue(0.0));
        yRand->SetAttribute("Max", DoubleValue(area));

        Ptr<RandomRectanglePositionAllocator> wpAlloc = CreateObject<RandomRectanglePositionAllocator>();
        wpAlloc->SetX(xRand);
        wpAlloc->SetY(yRand);

        mob.SetPositionAllocator(startPos);
        mob.SetMobilityModel("ns3::RandomWaypointMobilityModel",
                             "Speed", StringValue("ns3::ConstantRandomVariable[Constant=" + std::to_string(speed) + "]"),
                             "Pause", StringValue("ns3::ConstantRandomVariable[Constant=0.5]"),
                             "PositionAllocator", PointerValue(wpAlloc));
        mob.Install(nodes);
    };
    installSta(wifiSta);
    installSta(btSta);
    installSta(zgSta);

    // ---------- Received power sampling ----------
    RxStat rxWifi, rxBt, rxZg;
    Simulator::Schedule(Seconds(2.0), &SampleRx, MakeLoss(3.0), 20.0,
                        wifiAp.Get(0)->GetObject<MobilityModel>(),
                        wifiSta.Get(0)->GetObject<MobilityModel>(), &rxWifi);
    Simulator::Schedule(Seconds(2.0), &SampleRx, MakeLoss(2.5), 5.0,
                        btAp.Get(0)->GetObject<MobilityModel>(),
                        btSta.Get(0)->GetObject<MobilityModel>(), &rxBt);
    Simulator::Schedule(Seconds(2.0), &SampleRx, MakeLoss(3.0), 10.0,
                        zgAp.Get(0)->GetObject<MobilityModel>(),
                        zgSta.Get(0)->GetObject<MobilityModel>(), &rxZg);

    // ---------- Applications ----------
    uint16_t port = 5000;

    PacketSinkHelper wifiSink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port));
    ApplicationContainer wifiSinkApp = wifiSink.Install(wifiAp.Get(0));
    wifiSinkApp.Start(Seconds(1.0)); wifiSinkApp.Stop(Seconds(20.0));

    OnOffHelper wifiSrc("ns3::UdpSocketFactory", InetSocketAddress(wifiApIf.GetAddress(0), port));
    wifiSrc.SetAttribute("DataRate", StringValue("6Mbps"));
    wifiSrc.SetAttribute("PacketSize", UintegerValue(1024));
    wifiSrc.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    wifiSrc.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer wifiSrcApp = wifiSrc.Install(wifiSta.Get(0));
    wifiSrcApp.Start(Seconds(2.0)); wifiSrcApp.Stop(Seconds(20.0));

    PacketSinkHelper btSink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port + 1));
    ApplicationContainer btSinkApp = btSink.Install(btAp.Get(0));
    btSinkApp.Start(Seconds(1.0)); btSinkApp.Stop(Seconds(20.0));

    OnOffHelper btSrc("ns3::UdpSocketFactory", InetSocketAddress(btApIf.GetAddress(0), port + 1));
    btSrc.SetAttribute("DataRate", StringValue("500Kbps"));
    btSrc.SetAttribute("PacketSize", UintegerValue(512));
    btSrc.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    btSrc.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer btSrcApp = btSrc.Install(btSta.Get(0));
    btSrcApp.Start(Seconds(2.0)); btSrcApp.Stop(Seconds(20.0));

    PacketSinkHelper zgSink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(), port + 2));
    ApplicationContainer zgSinkApp = zgSink.Install(zgAp.Get(0));
    zgSinkApp.Start(Seconds(1.0)); zgSinkApp.Stop(Seconds(20.0));

    OnOffHelper zgSrc("ns3::UdpSocketFactory", InetSocketAddress(zgApIf.GetAddress(0), port + 2));
    zgSrc.SetAttribute("DataRate", StringValue("250Kbps"));
    zgSrc.SetAttribute("PacketSize", UintegerValue(128));
    zgSrc.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    zgSrc.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer zgSrcApp = zgSrc.Install(zgSta.Get(0));
    zgSrcApp.Start(Seconds(2.0)); zgSrcApp.Stop(Seconds(20.0));

    // ---------- Flow monitor & run ----------
    FlowMonitorHelper flowmon;
    Ptr<FlowMonitor> monitor = flowmon.InstallAll();

    Simulator::Stop(Seconds(20.0));
    Simulator::Run();

    monitor->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> classifier =
        DynamicCast<Ipv4FlowClassifier>(flowmon.GetClassifier());
    std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats();

    std::string tech[3] = {"WiFi", "Bluetooth", "Zigbee"};
    uint16_t ports[3] = {port, uint16_t(port + 1), uint16_t(port + 2)};
    RxStat *rx[3] = {&rxWifi, &rxBt, &rxZg};

    std::cout << "\nSpeed: " << speed << " m/s\n";
    std::cout << "==========================================\n";

    for (int i = 0; i < 3; i++) {
        for (auto &s : stats) {
            Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow(s.first);
            if (t.protocol != 17) continue;
            if (t.destinationPort != ports[i]) continue;

            double tp = s.second.rxBytes * 8.0 / appTime / 1e6;
            double avgDelay = (s.second.rxPackets > 0) ?
                (s.second.delaySum.GetSeconds() / s.second.rxPackets * 1000) : 0;
            double pdr = (s.second.txPackets > 0) ?
                ((double)s.second.rxPackets / s.second.txPackets * 100) : 0;
            double loss = 100.0 - pdr;
            double avgRx = (rx[i]->n > 0) ? rx[i]->sum / rx[i]->n : 0;

            std::cout << tech[i] << ":\n";
            std::cout << "  Avg Rx Power: " << avgRx << " dBm\n";
            std::cout << "  Min Rx Power: " << rx[i]->minV << " dBm\n";
            std::cout << "  Throughput  : " << tp << " Mbps\n";
            std::cout << "  Avg Delay   : " << avgDelay << " ms\n";
            std::cout << "  Packet Loss : " << loss << " %\n";
            std::cout << "  PDR         : " << pdr << " %\n\n";
        }
    }

    Simulator::Destroy();
    return 0;
}