#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#define BUF 4096

long ms() {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC,&t);
    return t.tv_sec*1000+t.tv_nsec/1000000;
}

int main() {
    char host[256],path[256],req[1024],buf[BUF],fname[256];
    int sockfd,bytes;
    long total=0;
    struct hostent *srv;
    struct sockaddr_in addr;
    FILE *fp;

    printf("Enter Domain (e.g., example.com): ");
    scanf("%255s",host);
    printf("Enter Path (e.g., / or /index.html): ");
    scanf("%255s",path);

    srv=gethostbyname(host);
    if(srv==NULL) {
        printf("Host not found\n");
        return 1;
    }

    sockfd=socket(AF_INET,SOCK_STREAM,0);
    if(sockfd<0) {
        perror("Socket error");
        return 1;
    }

    memset(&addr,0,sizeof(addr));
    addr.sin_family=AF_INET;
    addr.sin_port=htons(80);
    memcpy(&addr.sin_addr.s_addr,srv->h_addr_list[0],srv->h_length);

    long t1=ms();
    if(connect(sockfd,(struct sockaddr *)&addr,sizeof(addr))<0) {
        perror("Connect failed");
        close(sockfd);
        return 1;
    }
    long t2=ms();

    printf("Connected to %s\n",host);

    sprintf(req,"GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n",path,host);
    send(sockfd,req,strlen(req),0);

    snprintf(fname,sizeof(fname),"downloaded_%s",
             (strcmp(path,"/")==0)?"index.html":path+1);
    fp=fopen(fname,"wb");
    if(fp==NULL) {
        perror("File open error");
        close(sockfd);
        return 1;
    }

    int hdone=0;
    char hbuf[8192];
    int hlen=0;

    long t3=ms();
    while((bytes=recv(sockfd,buf,sizeof(buf),0))>0) {
        if(!hdone) {
            memcpy(hbuf+hlen,buf,bytes);
            hlen+=bytes;
            char *body=strstr(hbuf,"\r\n\r\n");
            if(body) {
                hdone=1;
                body+=4;
                int blen=hlen-(body-hbuf);
                fwrite(body,1,blen,fp);
                total+=blen;
            }
        } else {
            fwrite(buf,1,bytes,fp);
            total+=bytes;
        }
    }
    long t4=ms();

    fclose(fp);
    close(sockfd);

    long rtime=t2-t1;
    long dtime=t4-t3;
    double tput=(dtime>0)?(double)total/dtime*1000:0;

    printf("\n--- Performance Report ---\n");
    printf("File saved as : %s\n",fname);
    printf("Response Time : %ld ms\n",rtime);
    printf("Download Time : %ld ms\n",dtime);
    printf("Data Size     : %ld bytes\n",total);
    printf("Throughput    : %.2f bytes/sec\n",tput);

    return 0;
}
