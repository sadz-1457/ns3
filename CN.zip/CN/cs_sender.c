#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

unsigned short checksum(unsigned char *data,int len) {
    unsigned int sum=0;
    for(int i=0;i<len;i++) {
        sum+=data[i];
        while (sum>0xFF) {
            sum=(sum&0xFF)+(sum>>8);
        }
    }
    unsigned short cs=~sum&0xFF;
    printf("Checksum: %d -> ",cs);
    for(int b=7;b>=0;b--) printf("%d",(cs>>b)&1);
    printf("\n");
    return cs;
}

int main() {
    int server_fd,client_fd;
    struct sockaddr_in addr;
    char msg[100];
    unsigned char data[100];
    unsigned short cs;

    printf("Enter message: ");
    scanf(" %[^\n]",msg);
    int len=strlen(msg);
    for(int i=0;i<len;i++) data[i]=(unsigned char)msg[i];

    cs=checksum(data,len);
    printf("\nChecksum generated: %d\n",cs);

    server_fd=socket(AF_INET,SOCK_STREAM,0);
    int opt=1;
    setsockopt(server_fd,SOL_SOCKET,SO_REUSEADDR,&opt,sizeof(opt));
    addr.sin_family=AF_INET;
    addr.sin_addr.s_addr=INADDR_ANY;
    addr.sin_port=htons(9090);
    bind(server_fd,(struct sockaddr *)&addr,sizeof(addr));
    listen(server_fd,1);
    printf("Waiting for receiver...\n");
    client_fd=accept(server_fd,NULL,NULL);
    send(client_fd,msg,len+1,0);
    send(client_fd,&cs,sizeof(cs),0);
    printf("Data and checksum sent.\n");
    close(client_fd);
    close(server_fd);
    return 0;
}
