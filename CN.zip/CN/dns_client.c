#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define CACHE_SIZE 10
#define TIMEOUT 5

typedef struct {
    char domain[100];
    char ip[20];
} Cache;

Cache cache[CACHE_SIZE];
int cache_count=0;

char *check_cache(char *domain) {
    for(int i=0;i<cache_count;i++)
        if(strcmp(cache[i].domain,domain)==0)
            return cache[i].ip;
    return NULL;
}

void add_cache(char *domain,char *ip) {
    if(cache_count<CACHE_SIZE) {
        strcpy(cache[cache_count].domain,domain);
        strcpy(cache[cache_count].ip,ip);
        cache_count++;
    }
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char domain[100],buffer[100];

    sockfd=socket(AF_INET,SOCK_DGRAM,0);
    server_addr.sin_family=AF_INET;
    server_addr.sin_port=htons(8888);
    inet_pton(AF_INET,"127.0.0.1",&server_addr.sin_addr);

    //Timeout Logic
    struct timeval tv;
    tv.tv_sec=TIMEOUT;
    tv.tv_usec=0;
    setsockopt(sockfd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof(tv));

    while(1) {
        memset(domain,0,sizeof(domain));
        memset(buffer,0,sizeof(buffer));

        printf("\nEnter domain name (or 'exit' to quit): ");
        scanf("%s",domain);
        if(strcmp(domain,"exit")==0) break;

        //Checking the Cache first, and then proceeding with the server
        char *cached=check_cache(domain);
        if(cached) {
            printf("Result (from cache): %s\n",cached);
            continue;
        }

        sendto(sockfd,domain,strlen(domain),0,(struct sockaddr *)&server_addr,sizeof(server_addr));

        int r=recvfrom(sockfd,buffer,sizeof(buffer),0,NULL,NULL);
        if(r<0) { //Timeout Simulation
            printf("ERROR: Request timed out\n");
            continue;
        }

        printf("Result: %s\n",buffer);

        if(strcmp(buffer,"NXDOMAIN")!=0&&strcmp(buffer,"ERROR: Invalid format")!=0)
            add_cache(domain,buffer);
    }

    close(sockfd);
    return 0;
}
